﻿using Microsoft.AspNetCore.Mvc;

namespace TP4Bis_Castro.Controllers;

public class HomeController : Controller
{
    public IActionResult Index()
    {
        ViewBag.ListaPaises=Info.ListarPaises();
        return View("index");
    }//controler q tiene las acciones que va a aejecutar el usuario, tiene index y detalle pais ya que en algun momento el usuario va a querer saber eso y hay q pasar x el controler 
    public IActionResult DetallePais(string pais){//parametro q manda view para ver a que detalle acceder
        //toda la info de la lista en una view bag(llama al model) ya que necesita tener la info para pasarsela a la view 
        ViewBag.PaisBuscado=Info.DetallePais(pais);
        return View("detallepais");
    }
}
