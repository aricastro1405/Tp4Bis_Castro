public static class Info//estatica xq solo una clase maneja a todos los paises 
{
    private static  List<Pais>ListaPaises=new List<Pais>();
    private static void InicializarListas(){
        Pais unPais=new Pais("Argentina","Argentina.jpg",45000000,new DateTime(1816,7,9),"Cataratas");//objeto con toda la info de arg 
        ListaPaises.Add(unPais);
        unPais=new Pais("Brasil","Brasil.jpg",145000000,new DateTime(1816,7,10),"Amazonas");
        ListaPaises.Add(unPais);
        unPais=new Pais("Chile","Chile.jpg",245000000,new DateTime(1816,7,11),"Pucon");
        ListaPaises.Add(unPais);
        unPais=new Pais("Uruguay","Uruguay.jpg",5000000,new DateTime(1816,7,12),"Punta del Este");
        ListaPaises.Add(unPais);
        unPais=new Pais("Paraguay","Paraguay.jpg",35000000,new DateTime(1816,7,13),"Punta del Este");
        ListaPaises.Add(unPais);
    }
    //llena la lista ya que al principio no estaba llena 
    public static List<Pais> ListarPaises() {
        if (ListaPaises.Count==0){
            InicializarListas();
        }
        return ListaPaises;
    }
    public static Pais DetallePais(string Nombre){
        Pais PaisBuscado=new Pais();
        foreach(Pais item in ListaPaises){
            if(item.Nombre==Nombre){
                return item;// o tmb PaisBuscado=item;
            }
        }
        return PaisBuscado;
    }
} 
//controler q tiene las acciones que va a aejecutar el usuario, tiene index y detalle pais ya que en algun momento el usuario va a querer saber eso y hay q pasar x el controler 