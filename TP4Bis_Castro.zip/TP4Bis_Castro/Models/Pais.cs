public class Pais //no es estatica ya que va a almacenar muchos paises no solo un pais 
{
    public string Nombre{get;private set;}//private set=solo se puede llenar dentro de esta clase, ni en controller ni en view
    public string imgBandera{get;private set;}
    public int Poblacion {get;private set;}
    public DateTime FechaIndependencia{get; private set;}
    public string AtractivosTuristicos {get; private set;} 
    //Constructor vacio para cuando todavia no llenemos un valor de un objeto
    public Pais(){
        
    }
    //constructor para que cuando el usuario cree un objeto, en el parentesis le manda la informacion que es necesaria
    public Pais(string Nom,string Img,int Pob,DateTime FI,string AT){
        Nombre=Nom;
        imgBandera=Img;
        Poblacion=Pob;
        FechaIndependencia=FI;
        AtractivosTuristicos=AT;
    }
}